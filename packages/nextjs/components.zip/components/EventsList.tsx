import React, { useEffect, useState } from 'react';
import { useContractRead } from 'wagmi';
import { BigNumber } from 'ethers';

interface EventsListProps {
  contractAddress: string;
  abi: any;
}

export const EventsList: React.FC<EventsListProps> = ({ contractAddress, abi }) => {
  const [events, setEvents] = useState<any[]>([]);

  const { data: eventCount } = useContractRead({
    addressOrName: contractAddress,
    contractInterface: abi,
    functionName: 'getEventCount',
  });

  useEffect(() => {
    const fetchEvents = async () => {
      const loadedEvents = [];
      for (let i = 0; i < (eventCount as BigNumber).toNumber(); i++) {
        const event = await useContractRead({
          addressOrName: contractAddress,
          contractInterface: abi,
          functionName: 'getEventDetails',
          args: [i],
        });
        loadedEvents.push(event);
      }
      setEvents(loadedEvents);
    };

    if (eventCount) {
      fetchEvents();
    }
  }, [eventCount, contractAddress, abi]);

  return (
    <div>
      {events.map((event, index) => (
        <div key={index}>
          <h3>{event?.name}</h3>
          <p>{event?.description}</p>
          {/* Display other event details */}
        </div>
      ))}
    </div>
  );
};
